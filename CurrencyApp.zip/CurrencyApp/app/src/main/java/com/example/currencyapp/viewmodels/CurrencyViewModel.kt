package com.example.currencyapp.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.currencyapp.data.CurrencyRepository
import com.example.currencyapp.data.NBPTable
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.runBlocking

class CurrencyViewModel(application: Application): AndroidViewModel(application) {

    private val repository = CurrencyRepository()
    private lateinit var currencies: MutableLiveData<Array<NBPTable>>

    fun getCurrencies() = runBlocking {
        currencies = MutableLiveData()
        currencies.value = repository.getCurrencies().await()
        currencies
    }





}