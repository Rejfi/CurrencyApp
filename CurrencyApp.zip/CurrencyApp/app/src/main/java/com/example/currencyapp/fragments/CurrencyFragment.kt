package com.example.currencyapp.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.currencyapp.R
import com.example.currencyapp.adapters.NBPAdapter
import com.example.currencyapp.viewmodels.CurrencyViewModel

class CurrencyFragment: Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: NBPAdapter
    private lateinit var currencyViewModel: CurrencyViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.currency_fragment, container, false)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        currencyViewModel = ViewModelProvider
            .AndroidViewModelFactory(activity!!.application)
            .create(CurrencyViewModel::class.java)

    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        recyclerView = view!!.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)
        currencyViewModel.getCurrencies().observe(viewLifecycleOwner, Observer {
            adapter = NBPAdapter(it)
            setupAdapterToRecyclerView(recyclerView, adapter)
        })

    }
}



private fun setupAdapterToRecyclerView(recyclerView: RecyclerView, adapter: NBPAdapter){
   recyclerView.adapter = adapter
}