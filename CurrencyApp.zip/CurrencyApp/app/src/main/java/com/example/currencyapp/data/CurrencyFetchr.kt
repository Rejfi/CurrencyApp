package com.example.currencyapp.data

import android.net.Uri
import android.util.Log
import org.json.JSONException
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class CurrencyFetchr {

    private fun getUrlBytes(urlSpec: String): ByteArray {

        val url = URL(urlSpec)
        val connection = url.openConnection() as HttpURLConnection

        try {
            val out = ByteArrayOutputStream()
            val input = connection.inputStream

            if (connection.responseCode != HttpsURLConnection.HTTP_OK) {
                throw IOException(connection.responseMessage)
            }

            var bytesRead: Int
            val buffer = ByteArray(1025)

            do {
                bytesRead = input.read(buffer)

                out.write(buffer, 0, bytesRead)

            } while (input.read(buffer) > 0)

            out.close()

            return out.toByteArray()

        } catch (e: IOException) {
            Log.e("ERROR_HTTP_CONNECTION", e.message!!)
            return ByteArray(0)
        } finally {
            connection.disconnect()
        }
    }

    private fun getUrlString(urlSpec: String): String {
        return String(getUrlBytes(urlSpec))
    }


    fun getJSONString(): String {

        var jsonString = "COS POSZLO NIE TAK"

        try {
             val url: String = Uri.parse("http://api.nbp.pl/api/exchangerates/tables/A/")
                 .buildUpon()
                 .appendQueryParameter("?format", "json")
                 .build().toString()

             jsonString = getUrlString(url)

        } catch (je: JSONException) {
            Log.e("JSON_ERROR", je.message!!)
        }

        return jsonString
    }
}