package com.example.currencyapp.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async

class CurrencyRepository {

    fun getCurrencies(): Deferred<Array<NBPTable>> =
        CoroutineScope(Dispatchers.IO).async {
            val currencyFetchr = CurrencyFetchr()
            val gson = Gson()
            gson.fromJson(currencyFetchr.getJSONString(), Array<NBPTable>::class.java)
        }


}