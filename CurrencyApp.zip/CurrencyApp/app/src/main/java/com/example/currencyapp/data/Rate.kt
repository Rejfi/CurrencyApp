package com.example.currencyapp.data

data class Rate(
    val code: String,
    val currency: String,
    val mid: Double
)