package com.example.currencyapp.activities

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.currencyapp.R
import com.example.currencyapp.data.CurrencyFetchr
import com.example.currencyapp.data.NBPTable
import com.example.currencyapp.fragments.CurrencyFragment
import com.google.gson.Gson
import kotlinx.coroutines.*

lateinit var tabela: Array<NBPTable>

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fm = supportFragmentManager
        val currencyFragment = CurrencyFragment()
        fm.beginTransaction().apply {
            add(R.id.fragment_container, currencyFragment)
            commit()
        }

    }


}
